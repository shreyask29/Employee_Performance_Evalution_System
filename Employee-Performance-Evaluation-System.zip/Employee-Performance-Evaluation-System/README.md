# Employee Performance Evaluation System

A beginner-friendly Java desktop application that evaluates employee performance using three scores: Communication, Teamwork, and Productivity. It uses Java Swing/AWT for the graphical user interface and stores entries in a table while the application is running.

## Project details

- **Project title:** Employee Performance Evaluation System
- **Language:** Java
- **GUI:** Java Swing and AWT
- **Data handling:** `DefaultTableModel` (in-memory; no database required)
- **Requirements:** JDK 8 or newer
- **Team members:**
  - Shreyas Katiyar
  - Ritesh Kumar Sharma
  - Raj Singh

## Features

- Enter an employee name.
- Enter Communication, Teamwork, and Productivity scores from 0 to 10.
- Calculate the average score automatically.
- Assign a rating based on the average.
- Display employee details and results in a table.
- Validate empty names and invalid scores.
- Clear the input fields after adding a record.

## Rating criteria

| Average score | Rating |
|---|---|
| 8.00–10.00 | Excellent |
| 6.00–7.99 | Good |
| 4.00–5.99 | Average |
| Below 4.00 | Needs Improvement |

The average is calculated as:

`Average = (Communication + Teamwork + Productivity) / 3`

## Project structure

```text
Employee-Performance-Evaluation-System/
├── src/
│   └── Main.java
├── .gitignore
├── LICENSE
└── README.md
```

## Run on Windows using JDK

You do not need MySQL or any external library.

1. Install a JDK if it is not already installed.
2. Open the project folder in IntelliJ IDEA, or open Command Prompt in the project folder.
3. Compile from the project root:

   ```bash
   javac -d out src/Main.java
   ```

4. Run the application:

   ```bash
   java -cp out Main
   ```

### Run in IntelliJ IDEA

1. Open IntelliJ IDEA and choose **Open**.
2. Select this project folder.
3. Make sure a JDK is configured under **Project Structure → Project SDK**.
4. Open `src/Main.java`.
5. Click the green run icon next to `main()`.

## How to use

1. Enter the employee name.
2. Enter whole-number scores from 0 to 10 for all three criteria.
3. Click **Add Employee**.
4. The table displays the scores, average, and rating.
5. Click **Clear Fields** to clear the input fields.

## Limitations

- Data is stored only in memory and is lost when the application closes.
- The application does not include login, editing/deleting records, database storage, or report export.
- Scores must be whole numbers from 0 to 10.

## Future improvements

- Add database storage using JDBC and MySQL.
- Add edit/delete and search options.
- Export employee evaluations to CSV or PDF.
- Add employee login and administrator features.

## Academic submission note

Before submitting, review the code and make sure you can explain the GUI, input validation, average calculation, and rating conditions. Add screenshots of the application running if your project rubric requires them.
